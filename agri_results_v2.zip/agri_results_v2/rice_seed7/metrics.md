# Rice model evaluation

## Final model (exported TFLite)

Test images: 1285 · accuracy 89.2%

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Rice_Bacterial_Leaf_Blight | 0.578 | 0.840 | 0.685 | 75 |
| Rice_Brown_Spot | 0.708 | 0.791 | 0.747 | 86 |
| Rice_Healthy | 0.956 | 0.942 | 0.949 | 69 |
| Rice_Leaf_Blast | 0.838 | 0.594 | 0.695 | 165 |
| Rice_Leaf_scald | 0.778 | 0.677 | 0.724 | 93 |
| Rice_Sheath_Blight | 0.785 | 0.933 | 0.853 | 90 |
| Weed_Broadleaf | 0.993 | 0.993 | 0.993 | 143 |
| Weed_Grass | 0.998 | 0.998 | 0.998 | 564 |
| macro avg | 0.829 | 0.846 | 0.831 | |

Confusion matrix (rows = true, columns = predicted, order as above):

```
  63    2    0    9    0    1    0    0
   1   68    3    5    3    6    0    0
   0    2   65    0    0    2    0    0
  23   21    0   98   12   11    0    0
  20    3    0    4   63    3    0    0
   2    0    0    1    3   84    0    0
   0    0    0    0    0    0  142    1
   0    0    0    0    0    0    1  563
```
