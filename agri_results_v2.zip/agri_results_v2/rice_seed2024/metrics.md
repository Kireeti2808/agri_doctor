# Rice model evaluation

## Final model (exported TFLite)

Test images: 2682 · accuracy 94.9%

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Rice_Bacterial_Leaf_Blight | 0.784 | 0.696 | 0.737 | 125 |
| Rice_Brown_Spot | 0.890 | 0.770 | 0.826 | 126 |
| Rice_Healthy | 0.940 | 0.962 | 0.951 | 131 |
| Rice_Leaf_Blast | 0.672 | 0.873 | 0.760 | 134 |
| Rice_Leaf_scald | 0.880 | 0.716 | 0.789 | 102 |
| Rice_Sheath_Blight | 0.843 | 0.905 | 0.873 | 95 |
| Weed_Broadleaf | 0.979 | 0.997 | 0.988 | 368 |
| Weed_Grass | 0.999 | 0.995 | 0.997 | 1601 |
| macro avg | 0.873 | 0.864 | 0.865 | |

Confusion matrix (rows = true, columns = predicted, order as above):

```
  87    3    0   28    3    4    0    0
   1   97    6   15    2    5    0    0
   0    3  126    1    0    1    0    0
   8    4    0  117    4    1    0    0
  13    1    0   10   73    5    0    0
   2    1    2    3    1   86    0    0
   0    0    0    0    0    0  367    1
   0    0    0    0    0    0    8 1593
```
