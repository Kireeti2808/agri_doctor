# Rice model evaluation

## Baseline: old_rice.tflite

Test images: 1391 · accuracy 99.1%

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Rice_Bacterial_Leaf_Blight | 0.967 | 0.967 | 0.967 | 123 |
| Rice_Brown_Spot | 0.992 | 0.968 | 0.980 | 124 |
| Rice_Healthy | 1.000 | 1.000 | 1.000 | 131 |
| Rice_Leaf_Blast | 0.982 | 0.982 | 0.982 | 109 |
| Rice_Leaf_scald | 0.944 | 1.000 | 0.971 | 101 |
| Rice_Sheath_Blight | 1.000 | 0.969 | 0.984 | 96 |
| Weed_Broadleaf | 1.000 | 1.000 | 1.000 | 146 |
| Weed_Grass | 1.000 | 1.000 | 1.000 | 561 |
| macro avg | 0.986 | 0.986 | 0.986 | |

Confusion matrix (rows = true, columns = predicted, order as above):

```
 119    0    0    2    2    0    0    0
   0  120    0    0    4    0    0    0
   0    0  131    0    0    0    0    0
   1    1    0  107    0    0    0    0
   0    0    0    0  101    0    0    0
   3    0    0    0    0   93    0    0
   0    0    0    0    0    0  146    0
   0    0    0    0    0    0    0  561
```

## Final model (exported TFLite)

Test images: 1391 · accuracy 93.3%

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| Rice_Bacterial_Leaf_Blight | 0.754 | 0.870 | 0.808 | 123 |
| Rice_Brown_Spot | 0.932 | 0.879 | 0.905 | 124 |
| Rice_Healthy | 0.970 | 0.992 | 0.981 | 131 |
| Rice_Leaf_Blast | 0.810 | 0.899 | 0.852 | 109 |
| Rice_Leaf_scald | 0.901 | 0.634 | 0.744 | 101 |
| Rice_Sheath_Blight | 0.859 | 0.885 | 0.872 | 96 |
| Weed_Broadleaf | 0.986 | 1.000 | 0.993 | 146 |
| Weed_Grass | 1.000 | 0.996 | 0.998 | 561 |
| macro avg | 0.901 | 0.894 | 0.894 | |

Confusion matrix (rows = true, columns = predicted, order as above):

```
 107    1    0   12    1    2    0    0
   1  109    1    6    4    3    0    0
   0    0  130    0    0    1    0    0
   6    4    0   98    1    0    0    0
  23    3    1    2   64    8    0    0
   5    0    2    3    1   85    0    0
   0    0    0    0    0    0  146    0
   0    0    0    0    0    0    2  559
```
